<?php
	cherry_related_posts();
?>